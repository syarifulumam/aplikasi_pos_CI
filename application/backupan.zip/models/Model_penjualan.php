<?php
class Model_penjualan extends CI_Model {

	
	public function getData()
	{
    	return $this->db->get("transaksi")->result_array();
	}
	public function tambah_penjualan()
	{
		$nama = $this->input->post('nama');
		$jumlah = $this->input->post('jumlah');
		$harga = $this->input->post('harga');
		$tgl = explode("/",$this->input->post('tgl'));
		$tgl2 = implode('-', $tgl);
		$barang = $this->db->get_where('barang',array('nama'=>$nama))->row_array();
		$sisa = $barang['jumlah']-$jumlah;
		$this->db->set('jumlah',$sisa);
		$this->db->where('nama',$nama);
		$this->db->update('barang');


		$modal=$barang['modal'];
		$laba=$harga-$modal;
		$labaa=$laba*$jumlah;
		$total_harga=$harga*$jumlah;

    	$data = array(
    		'tanggal' => $tgl2,
    		'nama' => $this->input->post('nama'),
    		'jumlah' => $this->input->post('jumlah'),
    		'harga' => $this->input->post('harga'),
    		'total_harga' => $total_harga,
    		'laba' => $labaa
    	);
    	$this->db->insert('transaksi',$data);
	}
	public function selectData($id)
	{
    	$this->db->where('id',$id);
    	return $this->db->get('transaksi')->row_array();
	}
	public function edit_penjualan()
	{
		$id = $this->input->post('id');
		$nama = $this->input->post('nama');
		$jumlah = $this->input->post('jumlah');
		$harga = $this->input->post('harga');
		$tgl = explode("/"||'-',$this->input->post('tgl'));
		$tgl2 = implode('-', $tgl);
		$jumlah_penjualan = $this->db->get_where('transaksi',array('id'=>$id))->row_array();

		$barang = $this->db->get_where('barang',array('nama'=>$nama))->row_array();

		if ($jumlah > $jumlah_penjualan['jumlah']) {

			$hasil = $jumlah_penjualan['jumlah'] - $jumlah;
			$sisa = $barang['jumlah']+$hasil;
		}else{
			$hasil = $jumlah - $jumlah_penjualan['jumlah'] ;
			$sisa = $barang['jumlah']-$hasil;
		}
		$this->db->set('jumlah',$sisa);
		$this->db->where('nama',$nama);
		$this->db->update('barang');
		
		//MASIH GAGAL UPDATE JUMLAH BARANG

		$modal=$barang['modal'];
		$laba=$harga-$modal;
		$labaa=$laba*$jumlah;
		$total_harga=$harga*$jumlah;

    	$data = array(
    		'tanggal' => $tgl2,
    		'nama' => $this->input->post('nama'),
    		'jumlah' => $this->input->post('jumlah'),
    		'harga' => $this->input->post('harga'),
    		'total_harga' => $total_harga,
    		'laba' => $labaa
    	);
    	$this->db->where('id',$id);
    	$this->db->update('transaksi',$data);
	}

}
