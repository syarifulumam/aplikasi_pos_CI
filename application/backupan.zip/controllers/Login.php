<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	
	public function index()
	{
		//$data['jenis'] = $this->Model_jenis_barang->getData();

		$this->load->view('login');
	}

	public function proses(){
		if($this->input->post())
		{
	        $username   = $this->input->post('username');
	        $password   = $this->input->post('password');
	        $user = $this->db->get_where('user',array('uname'=>$username,'pass'=>$password))->num_rows();
	        if($user == 1)
	        {
	            $_SESSION['username']= $username;
	            redirect('data_barang');
	        }
	    }
	}

	public function logout()
	{
   		 $this->session->sess_destroy();
    	 redirect('login');
	}

}
