<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Costumer extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Model_costumer');
	}
	public function index()
	{
		$data['barang'] = $this->Model_costumer->getData();
		$this->template->load('template','costumer',$data);
	}
	public function tambah_costumer()
	{
		if($this->input->post())
    	{
           $this->Model_costumer->tambah_costumer();
           redirect('costumer');
    	}
		$this->template->load('template','tambah_costumer');
	}
	public function edit_costumer()
	{	
		if($this->input->post())
    	{
           $this->Model_costumer->edit_costumer();
           redirect('costumer');
    	}
    	$id = $this->uri->segment(3);
		$data['barang'] = $this->Model_costumer->selectData($id);
		$this->template->load('template','edit_costumer',$data);
	}
	public function delete_costumer($id)
	{
		$this->db->where('id',$id);
		$this->db->delete('user');
		redirect('costumer');
	}
}