<?php
class Model_data_barang extends CI_Model {

	
	public function getData()
	{
    	return $this->db->get("barang")->result_array();
	}
	public function tambah_barang()
	{
    	$data = array(
    		'nama' => $this->input->post('nama'),
    		'jenis' => $this->input->post('jenis'),
    		'suplier' => $this->input->post('suplier'),
    		'jumlah' => $this->input->post('stok'),
    		'modal' => $this->input->post('modal'),
    		'harga' => $this->input->post('jual'),
    	);
    	$this->db->insert('barang',$data);
	}
	public function selectData($id)
	{
		$this->db->where('id',$id);
    	return $this->db->get('barang')->row_array();
	}
	public function edit_barang()
	{
		$data = array(
    		'nama' => $this->input->post('nama'),
    		'jenis' => $this->input->post('jenis'),
    		'suplier' => $this->input->post('suplier'),
    		'jumlah' => $this->input->post('stok'),
    		'modal' => $this->input->post('modal'),
    		'harga' => $this->input->post('jual'),
    	);
    	$this->db->where('id',$this->input->post('id'));
    	$this->db->update('barang',$data);
	}

}
