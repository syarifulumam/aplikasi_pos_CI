<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class penjualan extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Model_penjualan');
	}
	public function index()
	{
		$data['penjualan'] = $this->Model_penjualan->getData();
		$this->template->load('template','penjualan',$data);
	}
	public function tambah_penjualan()
	{	
		if($this->input->post())
    	{
           $this->Model_penjualan->tambah_penjualan();
           redirect('penjualan');
    	}
    	$data['barang'] = $this->db->get('barang')->result_array();
		$this->template->load('template','tambah_penjualan',$data);
	}
	public function edit_penjualan($id)
	{	
		if($this->input->post())
    	{
           $this->Model_penjualan->edit_penjualan();
           redirect('penjualan');
    	}
		$data['penjualan'] = $this->Model_penjualan->selectData($id);
    	$data['barang'] = $this->db->get('barang')->result_array();
		$this->template->load('template','edit_penjualan',$data);
	}
	public function delete_penjualan($id)
	{
		$this->db->where('id',$id);
		$this->db->delete('transaksi');
		redirect('penjualan');
	}

}
