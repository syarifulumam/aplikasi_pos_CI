<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class data_barang extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Model_data_barang');
	}
	public function index()
	{
		$data['barang'] = $this->Model_data_barang->getData();
		$this->template->load('template','data_barang',$data);
	}
	public function tambah_barang()
	{
		if($this->input->post())
    	{
           $this->Model_data_barang->tambah_barang();
           redirect('data_barang');
    	}
    	$data['jenis'] = $this->db->get('jenis_barang')->result_array();
    	$data['suplier'] = $this->db->get('suplier')->result_array();
		$this->template->load('template','tambah_barang',$data);
	}
	public function edit_data_barang($id)
	{	
		if($this->input->post())
    	{
           $this->Model_data_barang->edit_barang();
           redirect('data_barang');
    	}
		$data['barang'] = $this->Model_data_barang->selectData($id);
    	$data['jenis'] = $this->db->get('jenis_barang')->result_array();
    	$data['suplier'] = $this->db->get('suplier')->result_array();
		$this->template->load('template','edit_data_barang',$data);
	}
	public function delete_data_barang($id)
	{
		$this->db->where('id',$id);
		$this->db->delete('barang');
		redirect('data_barang');
	}
	public function view_data_barang($id)
	{
		$data['barang'] = $this->Model_data_barang->selectData($id);
		$this->template->load('template','detail_data_barang',$data);
	}

}
