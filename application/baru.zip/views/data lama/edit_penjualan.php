        <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Quick Example</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <?= form_open('penjualan/edit_penjualan')  ?>
              <div class="box-body">
                <div class="form-group">
                  <label>Nama Barang</label>
                  <select class="form-control" name="nama">
                    <option>-- Pilih Nama Barang --</option>
                    <?php
                      foreach($barang as $b)
                      {
                    ?> 
                      <option value="<?=$b['nama'] ?>" <?= $b['nama']==$penjualan['nama']?'selected':''; ?> ><?=$b['nama'] ?></option>
                    <?php
                      }  
                    ?>
                  </select>
                </div>
                <div class="form-group">
                  <label>Harga Jual / Unit</label>
                  <input class="form-control" id="exampleInputEmail1" placeholder="Harga Jual" type="text" name="harga" value="<?= $penjualan['harga'] ?>">
                </div>
                <div class="form-group">
                  <label>Tanggal</label>
                <div class="input-group date">
                  <div class="input-group-addon">
                    <i class="fa fa-calendar"></i>
                  </div>
                  <input type="text" class="form-control pull-right" id="datepicker" name="tgl" value="<?= $penjualan['tanggal'] ?>">
                </div>
                <!-- /.input group -->
                </div>
                <div class="form-group">
                  <label>Jumlah</label>
                  <input class="form-control" id="exampleInputEmail1" placeholder="Jumlah" type="text" name="jumlah" value="<?= $penjualan['jumlah'] ?>">

                  <input class="form-control" id="exampleInputEmail1" placeholder="Jumlah" type="hidden" name="id" value="<?= $penjualan['id'] ?>">
                </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
              	<div class="pull-right">
                <button type="submit" class="btn btn-default">Kembali</button>
                <button type="submit" class="btn btn-primary">Submit</button>
            	</div>
              </div>
            </form>
          </div>
