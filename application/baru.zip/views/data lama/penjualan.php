          <div class="box">
            <div class="box-header">
              <?= anchor('penjualan/tambah_penjualan','Tambah','class="btn btn-primary"') ?>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Tanggal</th>
                  <th>Nama Barang</th>
                  <th>Jumlah</th>
                  <th>Harga Jual</th>
                  <th>Total</th>
                  <th>Laba</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php
                  $no = 1;
                  foreach ($penjualan as $j) {
                ?>
                <tr>
                  <td><?= $no ?></td>
                  <td><?= $j['tanggal'] ?></td>
                  <td><?= $j['nama'] ?></td>
                  <td><?= $j['jumlah'] ?></td>
                  <td><?= $j['harga'] ?></td>
                  <td><?= $j['total_harga'] ?></td>
                  <td><?= $j['laba'] ?></td>
                  <td>
                    <?= anchor('penjualan/edit_penjualan/'. $j['id'] ,'<i class="fa fa-edit"></i>','class="btn btn-warning btn-sm"') ?>
                    <?= anchor('penjualan/delete_penjualan/'. $j['id'] ,'<i class="fa fa-trash"></i>','class="btn btn-danger btn-sm"') ?>
                  </td>
                </tr>
                <?php
                    $no++;
                   } 
                ?>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
